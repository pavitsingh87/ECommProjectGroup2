<header>
        <nav class="navbar navbar-light promotion-nav">
            <div class="container">
                <p>Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%!</p>
                <p>ShopNow</p>
            </div>
        </nav>

        <!-- Navbar -->
        <nav data-mdb-navbar-init class="navbar navbar-expand-lg navbar-fixed-top border-bottom border-2">
            <div class="container">
                <button data-mdb-collapse-init class="navbar-toggler" type="button" data-mdb-target="#navbarExample01"
                    aria-controls="navbarExample01" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="images/logo.png" alt="" width="150" height="53">
                </a>
                <div class="collapse navbar-collapse" id="navbarExample01">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item active">
                            <a class="display-3 nav-link" aria-current="page" href="/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="display-3 nav-link" href="/about">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="display-3 nav-link" href="/products">Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="display-3 nav-link" href="/contact">Contact Us</a>
                        </li>
                    </ul>
                    <div class="navbar-nav navbar-info">
                        <ul class="navbar-nav justify-content-end me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a href="#"><i class="bi-search"></i></i></a>
                            </li>
                            <li class="nav-item">
                                <a href="#"><i class="bi bi-person-fill"></i></a>
                            </li>
                            <li class="nav-item">
                                <a href="#"><i class="bi bi-bag-fill"></i></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        <!-- Navbar -->
    </header><?php /**PATH C:\xampp\htdocs\ECommProjectGroup2\hockey_Shockey\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>